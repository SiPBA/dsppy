# Digital signal processing for educational purposes

Digital signal processing library adapted to the knowledge and needs of students of subjects related to signal processing.

